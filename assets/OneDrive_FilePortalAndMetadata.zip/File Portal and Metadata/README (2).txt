------Uploading Data to the EO4SD website----------

1. Log onto sign-up google cloud platform and follow link (https://console.cloud.google.com/storage/browser/eo4sd-271513.appspot.com?forceOnBucketsSortingFiltering=false&project=eo4sd-271513)
	You will just need a free account for now. Eventually we will begin paying for the storage on google as part of the EO4SD budget. This wont be necessary until after Christmas.
	Email Stephen Carpenter (stcarp@noc.ac.uk) to request autherisation to EO4SD bucket.
2. Upload data metadata file to an appropriate folder
3. Ensure the metadata element 'Online Linkage' is filled in for all data formats, including an XML link. (This will require uploading the metadata file twice; once to copy link into metadata file, then the new, saved xml) 
4. Send Uwe Kramer (uwe.kraemer@brockmann-consult.de) the following:
	1. URL for Metadata xml on google
	2. Quicklook image (150 width or less)
	3. Large image of dataset (e.g.PNG)


